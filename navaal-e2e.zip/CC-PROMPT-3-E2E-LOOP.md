# CLAUDE CODE PROMPT 3 — Run the E2E suite in a loop until the app is bulletproof

Copy the `navaal-e2e` folder's contents into the repo root (merging `tests/e2e/` and `playwright.config.js`), then paste everything below the line into Claude Code.

---

You are hardening the deployed Navaal Shopify app until an App Store reviewer cannot find a functional defect. A Playwright E2E suite has been added that tests the **live deployed app** through the Shopify admin's embedded iframe, and — critically — **verifies ground truth in the Shopify admin rather than trusting the app's own success messages.**

That distinction is the whole point. This app's worst bug was a UI that reported "Applied to Shopify" while writing nothing.

## SETUP (once)

```bash
npm i -D @playwright/test
npx playwright install chromium
echo "tests/e2e/.auth/" >> .gitignore
```

Authenticate once — **the human does this, headed, and logs in themselves. Never ask for their password, and never type credentials yourself:**
```bash
npx playwright test auth.setup.js --project=setup --headed
```

Then confirm the harness works:
```bash
npx playwright test 01-blockers.spec.js --project=desktop --grep "renders without technical strings"
```
If the frame locator in `tests/e2e/helpers.js` doesn't resolve, **fix `appFrame()` first** — inspect the real iframe attributes in the admin and adjust the selector. Nothing works until that's right.

## THE LOOP

Repeat until two consecutive full runs are green with zero skips that matter:

1. **Run**
   ```bash
   npx playwright test --project=desktop
   npx playwright test --project=tablet-768
   ```
2. **Read every failure properly.** Open the trace (`npx playwright show-trace`) and the screenshot. Do not guess from the error message.
3. **Classify each failure** before touching code:
   - **Real app defect** → fix the app.
   - **Bad test** (wrong selector, bad assumption, timing) → fix the test. Be honest about which it is; do not "fix" a test to make a real bug disappear.
   - **Environment** (expired session, store data missing) → fix the environment.
4. **For every real defect:** add a unit/integration test in the existing `vitest` suite that reproduces it, fix the cause, confirm both suites pass.
5. **Check for siblings.** Every bug in this app has had them — the concurrency throw was at six sites, the unchecked-mutation pattern at eleven. When you fix one, grep for the same shape everywhere.
6. **Gates before any deploy:**
   ```bash
   npx vitest run && npx eslint --ignore-path .gitignore . && npm run typecheck && npm run build
   ```
7. **Deploy.** Push to `main` and let CI deploy — **do not run `fly deploy` locally alongside a push**, it causes the release race that broke v84/v86. Poll `fly releases --app contentclaude`. Run `shopify app deploy` only if `shopify.app.toml` or `extensions/` changed.
8. **Re-run the suite against the new deploy.** Go to step 1.

Log each iteration: what failed, what you changed, what the next run showed.

## KNOWN OPEN DEFECTS — fix these first, they already have failing tests

**A. Legacy alt-text rows render a false success badge.**
Pre-fix rows in `GeneratedContent` were stored with `status: "published"` and a payload whose entries carry `error: "Field 'productImageUpdate' doesn't exist on type 'Mutation'"`. The Alt Text tab renders these with a green "Applied to Shopify" badge — so any product with a pre-fix attempt shows a reviewer the original bug verbatim. Observed live on `contentpilot-dev2` product `7629403652199`.
Fix both layers: (1) derive the badge purely from the stored per-image results so a row where every entry has an `error` renders "Not applied"; (2) one-time migration marking those legacy rows failed.
*Covered by:* `01-blockers.spec.js` → "a product whose alt text failed does NOT show a success badge".

**B. Dashboard draft count contradicts the review queue.**
Dashboard shows "Drafts Pending Review: 1" and "1 draft awaiting review" while `/app/review` correctly shows "Nothing to review". The dashboard metric still counts collection-scoped drafts that P0-2 filtered out. Apply the same `gid://shopify/Product/` filter to the dashboard metric and `getContentMetrics`, and audit every other place a draft count is surfaced.
*Covered by:* `01-blockers.spec.js` → "dashboard draft count matches what the review queue actually shows".

**C. Outcome-promising copy in the app UI.**
The dashboard and product-page banners read *"Written to rank on Google and get cited by ChatGPT, Perplexity, Gemini & Google AI Overviews."* That promises a result the app cannot control — requirement 1.1.4 (factual information only). Rewrite to describe the mechanism: answer-first structure, FAQPage JSON-LD, llms.txt. Sweep all in-app copy for the same pattern.
*Covered by:* `01-blockers.spec.js` → "in-app copy does not promise outcomes the app cannot control".

**D. Trial length must be one number everywhere.**
`app/shopify.server.js` sets `trialDays: 7`; navaal.ai advertises 14 days. Requirement 4.2.1 requires accurate trial disclosure. **Ask the human which is correct** before changing code, then make the app, the website and the listing agree.
*Covered by:* `02-workflows.spec.js` → "plans page shows four plans... and a consistent trial length".

**E. 768px overflow.** Never verified live. `responsive.spec.js` will tell you exactly which elements overflow and by how much.

## RULES

- **Never weaken an assertion to make a test pass.** If `getShopifyImageAltText` returns empty, the feature is broken — that is the test doing its job.
- **Never skip a test to get green.** A skip is a failure you chose not to look at. If a test must be skipped, say why in your report.
- The suite mutates a real store. Run sequentially (already configured). Don't add parallelism.
- Generation calls cost real credits and real money. Don't loop the suite needlessly — fix in batches, then re-run.
- If you find a defect the suite doesn't cover, **add a test for it**, then fix it.

## DEFINITION OF DONE

- Two consecutive full green runs on `desktop` and `tablet-768`
- `vitest`, `eslint`, `typecheck`, `build` all clean
- Deployed, and the suite green **against the deployed build**
- `playwright-report/` generated for the human to review
- A written report: every iteration, every defect found and fixed, every test added, anything still failing and why

Report honestly. "Three tests still fail and here's why" is worth far more than a green run achieved by softening assertions.

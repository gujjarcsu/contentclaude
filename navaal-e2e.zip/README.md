# Navaal E2E — Shopify App Store review suite

Tests the DEPLOYED app inside the real Shopify admin, and verifies ground truth
in the Shopify admin rather than trusting the app's own success messages.

## Install
    npm i -D @playwright/test
    npx playwright install chromium
    echo "tests/e2e/.auth/" >> .gitignore

## Authenticate (once, you log in yourself — no credentials in code)
    npx playwright test auth.setup.js --project=setup --headed

## Run
    npx playwright test --project=desktop
    npx playwright test --project=tablet-768
    npx playwright show-report

## Env overrides
    SHOP_HANDLE            default contentpilot-dev2
    ALT_TEXT_PRODUCT_ID    product with images, no prior alt-text run
    LEGACY_ALT_PRODUCT_ID  product with a pre-fix failed alt-text row
    WORKFLOW_PRODUCT_ID    product used for the core generate/publish loop

## Files
    playwright.config.js          sequential, real timeouts, traces on failure
    tests/e2e/auth.setup.js       one-time interactive login -> storageState
    tests/e2e/helpers.js          appFrame() iframe locator + Shopify ground-truth readers
    tests/e2e/01-blockers.spec.js P0 regressions (alt text, review queue, gates, copy)
    tests/e2e/02-workflows.spec.js end-to-end merchant journeys
    tests/e2e/responsive.spec.js  768px overflow + a11y smoke
